
Tracker:AddItems("items/items.json")
Tracker:AddItems("items/hint_items.json")
Tracker:AddItems("items/location_items.json")
Tracker:AddItems("items/labels.json")
                